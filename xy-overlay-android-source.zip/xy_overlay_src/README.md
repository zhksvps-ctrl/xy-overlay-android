# XY Overlay Android (v0.1.0)

A small Android app prototype for a movable floating XY shortcut bar.

## Included in this first build
- Android system overlay permission flow
- Foreground service keeps the overlay visible above other apps
- Drag handle, horizontal/vertical layout toggle, close button
- X-axis: 묶기 / 대입 / 대조 / 소거
- Y-axis: 라벨 / 분류 / 경로 / 검색
- Black axis surfaces, slim yellow header/frame, green numeric badges
- Button press animation and selection toast

## Not yet connected
The independent solver engine and automatic error verification/counting are not implemented in this UI prototype. Badges remain at zero until the verification engine is connected.

## Build
The provided repository workflow downloads Gradle 8.9 and runs `gradle assembleDebug` on GitHub Actions. It does not require a Gradle wrapper in the uploaded archive.
