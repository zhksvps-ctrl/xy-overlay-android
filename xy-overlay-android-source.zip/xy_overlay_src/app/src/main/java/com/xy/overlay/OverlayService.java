package com.xy.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private static final String CHANNEL_ID = "xy_overlay_running";
    private static final int NOTIFICATION_ID = 7314;
    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private boolean verticalLayout = false;
    private float touchDownX, touchDownY;
    private int startWindowX, startWindowY;
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        if (Settings.canDrawOverlays(this)) {
            buildOverlay();
        } else {
            Toast.makeText(this, "다른 앱 위에 표시 권한이 필요합니다.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "XY 플로팅 위젯", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("실행 중인 XY 단축바 오버레이 상태 알림");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder.setContentTitle("XY 플로팅 위젯 실행 중")
                .setContentText("알림을 눌러 위젯 설정으로 이동")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void buildOverlay() {
        int rememberedX = overlayParams == null ? dp(12) : overlayParams.x;
        int rememberedY = overlayParams == null ? dp(155) : overlayParams.y;
        if (overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
            overlayView = null;
        }

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(5), dp(5), dp(5), dp(5));
        shell.setBackground(roundRect(Color.rgb(12, 13, 16), dp(11), Color.rgb(255, 212, 59), dp(2)));
        shell.setElevation(dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(2), dp(4), dp(2));
        header.setBackground(roundRect(Color.rgb(255, 212, 59), dp(7), Color.rgb(255, 232, 140), dp(1)));

        TextView grip = new TextView(this);
        grip.setText("⠿");
        grip.setTextColor(Color.rgb(28, 28, 28));
        grip.setTextSize(21);
        grip.setGravity(Gravity.CENTER);
        header.addView(grip, new LinearLayout.LayoutParams(dp(28), dp(32)));
        attachDrag(grip);

        TextView title = new TextView(this);
        title.setText("XY 플로팅");
        title.setTextColor(Color.rgb(20, 21, 24));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(title, new LinearLayout.LayoutParams(dp(66), dp(32)));
        attachDrag(title);

        TextView errorLabel = new TextView(this);
        errorLabel.setText("오류 누적수");
        errorLabel.setTextColor(Color.rgb(30, 35, 32));
        errorLabel.setTextSize(9);
        header.addView(errorLabel, new LinearLayout.LayoutParams(-2, dp(28)));

        TextView errorBadge = new TextView(this);
        errorBadge.setText("0");
        errorBadge.setTextColor(Color.WHITE);
        errorBadge.setTextSize(10);
        errorBadge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        errorBadge.setGravity(Gravity.CENTER);
        errorBadge.setPadding(dp(5), 0, dp(5), 0);
        errorBadge.setBackground(roundRect(Color.rgb(20, 168, 83), dp(20), Color.rgb(90, 231, 144), dp(1)));
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2, dp(21));
        badgeLp.leftMargin = dp(3);
        header.addView(errorBadge, badgeLp);

        TextView orientation = headerButton(verticalLayout ? "↔" : "↕");
        LinearLayout.LayoutParams orientLp = new LinearLayout.LayoutParams(dp(32), dp(30));
        orientLp.leftMargin = dp(5);
        header.addView(orientation, orientLp);
        orientation.setOnClickListener(v -> {
            verticalLayout = !verticalLayout;
            buildOverlay();
        });

        TextView close = headerButton("×");
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(28), dp(30));
        closeLp.leftMargin = dp(3);
        header.addView(close, closeLp);
        close.setOnClickListener(v -> stopSelf());
        shell.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout axes = new LinearLayout(this);
        axes.setOrientation(verticalLayout ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        axes.setPadding(0, dp(3), 0, 0);
        axes.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams axesLp = new LinearLayout.LayoutParams(-2, -2);
        axesLp.topMargin = dp(2);
        shell.addView(axes, axesLp);

        String[] xActions = {"묶기", "대입", "대조", "소거"};
        String[] yActions = {"라벨", "분류", "경로", "검색"};
        axes.addView(buildAxis("X축", xActions), new LinearLayout.LayoutParams(-2, -2));
        axes.addView(buildAxis("Y축", yActions), new LinearLayout.LayoutParams(-2, -2));

        overlayView = shell;
        int windowType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = rememberedX;
        overlayParams.y = rememberedY;
        try {
            windowManager.addView(overlayView, overlayParams);
            overlayView.setAlpha(0f);
            overlayView.animate().alpha(1f).setDuration(160).start();
        } catch (Exception ex) {
            Toast.makeText(this, "위젯 표시 실패: 권한을 확인해 주세요.", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private LinearLayout buildAxis(String axisName, String[] labels) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(verticalLayout ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        group.setGravity(Gravity.CENTER_VERTICAL);
        group.setBackgroundColor(Color.BLACK);
        group.setPadding(dp(1), dp(1), dp(1), dp(1));

        TextView axis = new TextView(this);
        axis.setText(axisName);
        axis.setTextColor(Color.rgb(190, 194, 204));
        axis.setTextSize(10);
        axis.setGravity(Gravity.CENTER);
        if (verticalLayout) {
            group.addView(axis, new LinearLayout.LayoutParams(dp(70), dp(20)));
        } else {
            group.addView(axis, new LinearLayout.LayoutParams(dp(25), dp(43)));
        }

        for (String label : labels) {
            LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(dp(67), dp(43));
            if (verticalLayout) {
                cellLp.topMargin = dp(2);
                cellLp.bottomMargin = dp(2);
            } else {
                cellLp.leftMargin = dp(2);
                cellLp.rightMargin = dp(2);
            }
            group.addView(buildActionCell(label), cellLp);
        }
        return group;
    }

    private View buildActionCell(String label) {
        FrameLayout cell = new FrameLayout(this);
        cell.setBackground(roundRect(Color.rgb(34, 36, 43), dp(9), Color.rgb(105, 111, 123), dp(1)));
        cell.setElevation(dp(3));
        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(Color.WHITE);
        text.setTextSize(12);
        text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setGravity(Gravity.CENTER);
        cell.addView(text, new FrameLayout.LayoutParams(-1, -1));

        TextView badge = new TextView(this);
        badge.setText("0");
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(8);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(roundRect(Color.rgb(20, 168, 83), dp(18), Color.rgb(80, 222, 135), dp(1)));
        FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(dp(17), dp(14), Gravity.TOP | Gravity.RIGHT);
        badgeLp.rightMargin = dp(2);
        badgeLp.topMargin = dp(2);
        cell.addView(badge, badgeLp);

        cell.setOnClickListener(v -> {
            v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction(() ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
            Toast.makeText(this, label + " 선택", Toast.LENGTH_SHORT).show();
        });
        cell.setOnLongClickListener(v -> {
            Toast.makeText(this, "오류 누적수 자동 집계는 풀이 검증 엔진 연결 후 활성화됩니다.", Toast.LENGTH_LONG).show();
            return true;
        });
        return cell;
    }

    private TextView headerButton(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(Color.rgb(25, 26, 29));
        view.setTextSize(19);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setBackground(roundRect(Color.rgb(255, 226, 111), dp(7), Color.rgb(160, 127, 16), dp(1)));
        return view;
    }

    private GradientDrawable roundRect(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener((view, event) -> {
            if (overlayParams == null || overlayView == null) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchDownX = event.getRawX();
                    touchDownY = event.getRawY();
                    startWindowX = overlayParams.x;
                    startWindowY = overlayParams.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = startWindowX + (int) (event.getRawX() - touchDownX);
                    overlayParams.y = startWindowY + (int) (event.getRawY() - touchDownY);
                    try { windowManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) { }
                    return true;
                case MotionEvent.ACTION_UP:
                    return true;
                default:
                    return false;
            }
        });
    }

    @Override
    public void onDestroy() {
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
            overlayView = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
