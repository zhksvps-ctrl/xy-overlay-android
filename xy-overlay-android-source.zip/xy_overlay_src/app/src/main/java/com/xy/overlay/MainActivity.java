package com.xy.overlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY_PERMISSION = 1001;
    private TextView statusView;
    private boolean startWhenPermissionReturns = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(16, 18, 24));
        window.setNavigationBarColor(Color.rgb(16, 18, 24));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(28));
        page.setGravity(Gravity.TOP);
        page.setBackgroundColor(Color.rgb(16, 18, 24));

        TextView title = new TextView(this);
        title.setText("XY 플로팅 위젯");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("다른 앱 위에 표시되는 묶기·대입·대조·소거 및 라벨·분류·경로·검색 단축바");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(208, 211, 220));
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(12);
        page.addView(subtitle, subtitleLp);

        statusView = new TextView(this);
        statusView.setTextColor(Color.rgb(255, 212, 59));
        statusView.setTextSize(14);
        statusView.setText(Settings.canDrawOverlays(this)
                ? "오버레이 권한: 허용됨"
                : "오버레이 권한: 허용 필요");
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(22);
        page.addView(statusView, statusLp);

        Button start = makeButton("플로팅 위젯 시작", true);
        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(-1, dp(54));
        startLp.topMargin = dp(18);
        page.addView(start, startLp);
        start.setOnClickListener(v -> startOverlayFlow());

        Button stop = makeButton("플로팅 위젯 종료", false);
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, dp(54));
        stopLp.topMargin = dp(10);
        page.addView(stop, stopLp);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            statusView.setText("플로팅 위젯이 종료되었습니다.");
        });

        TextView note = new TextView(this);
        note.setText("사용 방법\n1. 시작을 누릅니다.\n2. 다른 앱 위에 표시 권한을 허용합니다.\n3. 노란색 상단 손잡이로 위젯을 이동하고 ↔/↕ 버튼으로 방향을 바꿉니다.\n\n이 버전은 플로팅 UI와 조작 동작을 검증하는 첫 빌드입니다. 풀이 엔진과 실제 오류 자동 집계는 아직 연결되지 않았습니다.");
        note.setTextColor(Color.rgb(180, 185, 196));
        note.setTextSize(14);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(24);
        page.addView(note, noteLp);

        setContentView(page);
    }

    private void startOverlayFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startWhenPermissionReturns = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        Intent serviceIntent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        statusView.setText("플로팅 위젯 시작 요청 완료");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                statusView.setText("오버레이 권한: 허용됨");
                if (startWhenPermissionReturns) {
                    startWhenPermissionReturns = false;
                    startOverlayService();
                }
            } else {
                statusView.setText("권한이 허용되지 않았습니다. 시작하려면 권한을 허용해 주세요.");
            }
        }
    }

    private Button makeButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(primary ? Color.rgb(22, 24, 28) : Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? Color.rgb(255, 212, 59) : Color.rgb(47, 51, 61));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), primary ? Color.rgb(255, 229, 130) : Color.rgb(85, 91, 105));
        button.setBackground(bg);
        return button;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
