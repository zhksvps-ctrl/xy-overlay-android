package com.xy.lite

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(0xFF111827.toInt())
        }
        val title = TextView(this).apply {
            text = "XY 라이트 위젯"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 14)
        }
        val launchOverlay = Button(this).apply {
            text = "다른 앱 위에 위젯 띄우기"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingWidgetService::class.java))
                    Toast.makeText(this@MainActivity, "플로팅 위젯을 실행했습니다.", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
            }
        }
        val hint = TextView(this).apply {
            text = "처음 한 번은 ‘다른 앱 위에 표시’ 권한을 허용하세요.\n아래에서 전체 화면으로도 사용할 수 있습니다."
            textSize = 14f
            setTextColor(0xFFD1D5DB.toInt())
            setPadding(0, 8, 0, 12)
        }
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(launchOverlay, LinearLayout.LayoutParams(-1, -2))
        root.addView(hint, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
