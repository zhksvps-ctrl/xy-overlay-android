package com.xy.lite

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class FloatingWidgetService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF111827.toInt())
            setPadding(10, 4, 6, 4)
        }
        val label = TextView(this).apply {
            text = "XY 라이트 위젯  ·  길게 끌어 이동"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(4, 8, 4, 8)
        }
        val close = TextView(this).apply {
            text = "닫기  ×"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(12, 8, 8, 8)
            setOnClickListener { stopSelf() }
        }
        bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(close, LinearLayout.LayoutParams(-2, -2))
        bar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }
        val web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92f).toInt().coerceAtMost(420),
            (resources.displayMetrics.heightPixels * 0.72f).toInt().coerceAtLeast(420),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 100 }
        overlay = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
}
