XY 라이트 위젯 Android 프로젝트

기능
- 앱 아이콘으로 전체 화면 실행
- ‘다른 앱 위에 위젯 띄우기’ 버튼으로 시스템 오버레이 실행
- 오버레이 상단 바를 끌어 위치 이동, 닫기 버튼으로 종료
- HTML 시제품의 X/Y 버튼, 가로·세로 전환, 버튼별 오류 누적수 사용

APK 빌드 (PC 없이 GitHub Actions 사용)
1. 저장소의 기존 파일을 백업합니다.
2. 이 ZIP의 안쪽 파일/폴더(app, .github, build.gradle, settings.gradle, gradle.properties, README_KO.txt)를 저장소 루트에 업로드합니다. ZIP 파일 자체만 업로드하면 빌드되지 않습니다.
3. GitHub 저장소의 Actions 탭에서 “Build XY Lite Android APK” 실행을 확인합니다.
4. 성공한 실행의 Artifacts에서 xy-lite-widget-debug-apk를 다운로드하고 ZIP을 풀어 app-debug.apk를 갤럭시에 설치합니다.

참고
- 이 프로젝트는 디버그 APK입니다. 최초 설치 시 Android에서 출처/설치 허용 확인이 필요할 수 있습니다.
- 오버레이 실행 시 설정에서 ‘다른 앱 위에 표시’를 허용해야 합니다.
- 버튼별 카운트는 WebView 로컬 저장소를 사용합니다. 앱 전체 화면과 오버레이의 WebView 저장소는 Android 버전/설정에 따라 분리되어 보일 수 있습니다.
- 실제 APK 빌드/기기 테스트는 GitHub Actions 실행 후 확인해야 합니다.
