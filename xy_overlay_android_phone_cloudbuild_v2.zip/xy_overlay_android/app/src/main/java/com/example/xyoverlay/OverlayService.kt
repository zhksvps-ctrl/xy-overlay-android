package com.example.xyoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.animation.LayoutTransition
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableMapOf<String, View>()
    private val params = mutableMapOf<String, WindowManager.LayoutParams>()
    private val green = Color.rgb(22, 131, 74)
    private val red = Color.rgb(217, 54, 54)
    private val yellow = Color.rgb(242, 201, 76)
    private val prefs by lazy { getSharedPreferences("xy_overlay", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(4001, buildNotification())
        addBar("X", listOf("묶기", "대입", "대조", "소거"), red, Color.WHITE, 0.30f)
        addBar("Y", listOf("라벨", "분류", "경로", "검색"), yellow, Color.rgb(41, 41, 41), 0.43f)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("xy_overlay_running", "XY 플로팅 단축바", NotificationManager.IMPORTANCE_LOW).apply {
                description = "다른 앱 위에 XY 단축바를 표시하는 동안 유지됩니다."
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, "xy_overlay_running") else Notification.Builder(this)
        return builder.setContentTitle("XY 플로팅 단축바 실행 중")
            .setContentText("다른 앱 위에 풀이 버튼을 표시하고 있습니다.")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .build()
    }

    private fun addBar(axis: String, labels: List<String>, buttonColor: Int, textColor: Int, defaultY: Float) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        val bg = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(9).toFloat()
            setStroke(dp(1), Color.rgb(227, 231, 237))
        }
        bar.background = bg
        // Animate child repositioning when the bar changes between horizontal and vertical layouts.
        bar.layoutTransition = LayoutTransition().apply {
            setDuration(260)
            enableTransitionType(LayoutTransition.CHANGING)
            enableTransitionType(LayoutTransition.APPEARING)
            enableTransitionType(LayoutTransition.DISAPPEARING)
        }
        val rotate = TextView(this).apply {
            text = "↻"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(70, 80, 94))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(248, 250, 252)); cornerRadius = dp(5).toFloat()
                setStroke(dp(1), Color.rgb(215, 220, 227))
            }
            layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)).apply {
                if (prefs.getBoolean("vertical_$axis", false)) bottomMargin = dp(2) else rightMargin = dp(3)
            }
            setOnClickListener {
                val vertical = !prefs.getBoolean("vertical_$axis", false)
                prefs.edit().putBoolean("vertical_$axis", vertical).apply()
                // Give the direction toggle a short visual cue while children reflow.
                animate().cancel()
                animate().rotationBy(90f).setDuration(260).start()
                bar.animate().cancel()
                bar.animate().alpha(0.78f).scaleX(0.97f).scaleY(0.97f)
                    .setDuration(100).withEndAction {
                        bar.orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
                        val rp = layoutParams as LinearLayout.LayoutParams
                        rp.rightMargin = if (vertical) 0 else dp(3)
                        rp.bottomMargin = if (vertical) dp(2) else 0
                        layoutParams = rp
                        // Wait for the new dimensions before clamping the floating window.
                        bar.post {
                            params[axis]?.let { lp ->
                                val maxX = max(0, resources.displayMetrics.widthPixels - bar.width)
                                val maxY = max(0, resources.displayMetrics.heightPixels - bar.height)
                                lp.x = min(lp.x, maxX)
                                lp.y = min(lp.y, maxY)
                                try {
                                    wm.updateViewLayout(bar, lp)
                                    prefs.edit().putInt("x_$axis", lp.x).putInt("y_$axis", lp.y).apply()
                                } catch (_: IllegalArgumentException) { }
                            }
                            bar.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
                        }
                    }.start()
                Toast.makeText(this@OverlayService, if (vertical) "세로 방향" else "가로 방향", Toast.LENGTH_SHORT).show()
            }
        }
        bar.orientation = if (prefs.getBoolean("vertical_$axis", false)) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        bar.addView(rotate)
        labels.forEach { label ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(1), 0, dp(1), 0)
            }
            val badge = TextView(this).apply {
                text = prefs.getInt("err_$label", 0).let { if (it > 0) it.toString() else "" }
                textSize = 8f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(green)
                }
                val size = dp(12)
                layoutParams = LinearLayout.LayoutParams(size, size).apply { bottomMargin = dp(1) }
                visibility = if (text.isNullOrEmpty()) View.INVISIBLE else View.VISIBLE
            }
            val button = TextView(this).apply {
                text = label
                textSize = 6.5f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(textColor)
                background = arcadeButtonDrawable(buttonColor)
                elevation = dp(3).toFloat()
                setShadowLayer(dp(1).toFloat(), 0f, dp(1).toFloat(), 0x33000000)
                val size = dp(22)
                layoutParams = LinearLayout.LayoutParams(size, size)
                setOnClickListener {
                    animate().cancel()
                    scaleX = 1f; scaleY = 1f; translationY = 0f
                    animate().scaleX(0.91f).scaleY(0.91f).translationY(dp(2).toFloat()).setDuration(65).withEndAction {
                        animate().scaleX(1.045f).scaleY(1.045f).translationY(0f).alpha(0.88f).setDuration(75).withEndAction {
                            animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(85).start()
                        }.start()
                    }.start()
                    if (label == "검색") {
                        Toast.makeText(this@OverlayService, "검색은 앱 내부 문제 입력창과 연결해야 합니다.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@OverlayService, "$label 기능 선택 — 풀이 엔진 연결 필요", Toast.LENGTH_SHORT).show()
                    }
                }
                setOnLongClickListener {
                    val next = prefs.getInt("err_$label", 0) + 1
                    prefs.edit().putInt("err_$label", next).apply()
                    badge.text = next.toString()
                    badge.visibility = View.VISIBLE
                    Toast.makeText(this@OverlayService, "$label 오류 누적: $next", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            column.addView(badge)
            column.addView(button)
            bar.addView(column)
        }

        val savedX = prefs.getInt("x_$axis", -1)
        val savedY = prefs.getInt("y_$axis", -1)
        val display = resources.displayMetrics
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (savedX >= 0) savedX else max(0, (display.widthPixels - dp(270)) / 2)
            y = if (savedY >= 0) savedY else (display.heightPixels * defaultY).toInt()
        }
        attachDrag(bar, axis, p)
        wm.addView(bar, p)
        views[axis] = bar
        params[axis] = p
    }

    private fun attachDrag(view: View, axis: String, lp: WindowManager.LayoutParams) {
        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        var dragging = false
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = lp.x; initialY = lp.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - startX).toInt()
                    val dy = (event.rawY - startY).toInt()
                    if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) dragging = true
                    if (dragging) {
                        val maxX = max(0, resources.displayMetrics.widthPixels - v.width)
                        val maxY = max(0, resources.displayMetrics.heightPixels - v.height)
                        lp.x = min(max(0, initialX + dx), maxX)
                        lp.y = min(max(0, initialY + dy), maxY)
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) prefs.edit().putInt("x_$axis", lp.x).putInt("y_$axis", lp.y).apply()
                    true
                }
                else -> false
            }
        }
        // The bar itself handles empty-space dragging; child buttons keep their click/long-click actions.
    }


    private fun arcadeButtonDrawable(base: Int): android.graphics.drawable.Drawable {
        fun shade(color: Int, factor: Float): Int = Color.rgb(
            (Color.red(color) * factor).toInt().coerceIn(0, 255),
            (Color.green(color) * factor).toInt().coerceIn(0, 255),
            (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        )
        fun oval(colors: IntArray, strokeColor: Int, strokeWidth: Int = 1): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors
            ).apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setStroke(dp(strokeWidth), strokeColor)
            }

        // Three physical-looking layers: dark socket, metallic bezel, raised domed cap.
        val socket = oval(intArrayOf(Color.rgb(24, 27, 33), Color.rgb(62, 67, 75), Color.rgb(15, 17, 21)), Color.rgb(18, 20, 24), 1)
        val bezel = oval(intArrayOf(Color.rgb(248, 249, 251), Color.rgb(150, 158, 169), Color.rgb(49, 54, 62)), Color.rgb(86, 92, 101), 1)
        val cap = oval(intArrayOf(shade(base, 1.32f), shade(base, 1.10f), base, shade(base, 0.70f)), shade(base, 0.62f), 1)
        return android.graphics.drawable.LayerDrawable(arrayOf(socket, bezel, cap)).apply {
            setLayerInset(0, 0, 0, 0, 0)
            setLayerInset(1, dp(1), dp(1), dp(1), dp(1))
            setLayerInset(2, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onDestroy() {
        views.values.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear(); params.clear()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
