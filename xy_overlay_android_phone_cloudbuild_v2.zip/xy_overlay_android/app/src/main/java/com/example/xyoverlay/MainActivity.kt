package com.example.xyoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 10)
            setBackgroundColor(0xFFF3F5F8.toInt())
        }
        val title = TextView(this).apply {
            text = "XY 문제풀이 단축바"
            textSize = 22f
            setTextColor(0xFF202938.toInt())
            setPadding(0, 0, 0, 10)
        }
        val description = TextView(this).apply {
            text = "웹 화면에서 문제풀이를 사용하거나, 시스템 플로팅을 켜서 다른 앱 위에 XY 단축바를 표시하세요."
            textSize = 14f
            setTextColor(0xFF475467.toInt())
            setPadding(0, 0, 0, 12)
        }
        val start = Button(this).apply {
            text = "다른 앱 위에 XY 플로팅 표시"
            setOnClickListener { enableOverlay() }
        }
        val stop = Button(this).apply {
            text = "플로팅 종료"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        root.addView(title)
        root.addView(description)
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = 12 })
        setContentView(root)
    }

    private fun enableOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
            Toast.makeText(this, "앱 위에 표시 권한을 허용한 뒤 다시 켜 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        startOverlayService()
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "XY 플로팅을 시작했습니다.", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
            startOverlayService()
        }
    }
}
