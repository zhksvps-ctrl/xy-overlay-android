# Build the XY Overlay APK using only a phone

This project includes a GitHub Actions workflow that can build a debug APK in the cloud. It does not mean the APK has already been built or tested.

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository. If the repository is public, remember the source will be public too; choose private if you want to keep it private.
3. Upload the *contents* of this `xy_overlay_android` folder to the repository (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab and select **Build XY Overlay APK**. If prompted, enable workflows, then tap **Run workflow**.
5. Wait for the run to finish successfully. Open that run and download the `xy-overlay-debug-apk` artifact. GitHub downloads it as a ZIP; extract it in the phone's Files app to get `app-debug.apk`.
6. Tap the APK to install it. If Android blocks installation, allow installs from that source only if you trust the repository and build.
7. Open the app, grant “Display over other apps” permission, and start the overlay.

The orientation toggle now waits for the bar to finish re-layout before correcting its screen position, with a short fade/scale transition. The current code has not been validated by a real Android build/device test. If the cloud build fails, open the failed workflow log and share a screenshot of the error.
